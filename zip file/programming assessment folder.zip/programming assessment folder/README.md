<style type="text/css">.rendered-markdown{font-size:14px} .rendered-markdown>*:first-child{margin-top:0!important} .rendered-markdown>*:last-child{margin-bottom:0!important} .rendered-markdown a{text-decoration:underline;color:#b75246} .rendered-markdown a:hover{color:#f36050} .rendered-markdown h1, .rendered-markdown h2, .rendered-markdown h3, .rendered-markdown h4, .rendered-markdown h5, .rendered-markdown h6{margin:24px 0 10px;padding:0;font-weight:bold;-webkit-font-smoothing:antialiased;cursor:text;position:relative} .rendered-markdown h1 tt, .rendered-markdown h1 code, .rendered-markdown h2 tt, .rendered-markdown h2 code, .rendered-markdown h3 tt, .rendered-markdown h3 code, .rendered-markdown h4 tt, .rendered-markdown h4 code, .rendered-markdown h5 tt, .rendered-markdown h5 code, .rendered-markdown h6 tt, .rendered-markdown h6 code{font-size:inherit} .rendered-markdown h1{font-size:28px;color:#000} .rendered-markdown h2{font-size:22px;border-bottom:1px solid #ccc;color:#000} .rendered-markdown h3{font-size:18px} .rendered-markdown h4{font-size:16px} .rendered-markdown h5{font-size:14px} .rendered-markdown h6{color:#777;font-size:14px} .rendered-markdown p, .rendered-markdown blockquote, .rendered-markdown ul, .rendered-markdown ol, .rendered-markdown dl, .rendered-markdown table, .rendered-markdown pre{margin:15px 0} .rendered-markdown hr{border:0 none;color:#ccc;height:4px;padding:0} .rendered-markdown>h2:first-child, .rendered-markdown>h1:first-child, .rendered-markdown>h1:first-child+h2, .rendered-markdown>h3:first-child, .rendered-markdown>h4:first-child, .rendered-markdown>h5:first-child, .rendered-markdown>h6:first-child{margin-top:0;padding-top:0} .rendered-markdown a:first-child h1, .rendered-markdown a:first-child h2, .rendered-markdown a:first-child h3, .rendered-markdown a:first-child h4, .rendered-markdown a:first-child h5, .rendered-markdown a:first-child h6{margin-top:0;padding-top:0} .rendered-markdown h1+p, .rendered-markdown h2+p, .rendered-markdown h3+p, .rendered-markdown h4+p, .rendered-markdown h5+p, .rendered-markdown h6+p{margin-top:0} .rendered-markdown ul, .rendered-markdown ol{padding-left:30px} .rendered-markdown ul li>:first-child, .rendered-markdown ul li ul:first-of-type, .rendered-markdown ol li>:first-child, .rendered-markdown ol li ul:first-of-type{margin-top:0} .rendered-markdown ul ul, .rendered-markdown ul ol, .rendered-markdown ol ol, .rendered-markdown ol ul{margin-bottom:0} .rendered-markdown dl{padding:0} .rendered-markdown dl dt{font-size:14px;font-weight:bold;font-style:italic;padding:0;margin:15px 0 5px} .rendered-markdown dl dt:first-child{padding:0} .rendered-markdown dl dt>:first-child{margin-top:0} .rendered-markdown dl dt>:last-child{margin-bottom:0} .rendered-markdown dl dd{margin:0 0 15px;padding:0 15px} .rendered-markdown dl dd>:first-child{margin-top:0} .rendered-markdown dl dd>:last-child{margin-bottom:0} .rendered-markdown blockquote{border-left:4px solid #DDD;padding:0 15px;color:#777} .rendered-markdown blockquote>:first-child{margin-top:0} .rendered-markdown blockquote>:last-child{margin-bottom:0} .rendered-markdown table th{font-weight:bold} .rendered-markdown table th, .rendered-markdown table td{border:1px solid #ccc;padding:6px 13px} .rendered-markdown table tr{border-top:1px solid #ccc;background-color:#fff} .rendered-markdown table tr:nth-child(2n){background-color:#f8f8f8} .rendered-markdown img{max-width:100%;-moz-box-sizing:border-box;box-sizing:border-box} .rendered-markdown code, .rendered-markdown tt{margin:0 2px;padding:0 5px;border:1px solid #eaeaea;background-color:#f8f8f8;border-radius:3px} .rendered-markdown code{white-space:nowrap} .rendered-markdown pre>code{margin:0;padding:0;white-space:pre;border:0;background:transparent} .rendered-markdown .highlight pre, .rendered-markdown pre{background-color:#f8f8f8;border:1px solid #ccc;font-size:13px;line-height:19px;overflow:auto;padding:6px 10px;border-radius:3px} .rendered-markdown pre code, .rendered-markdown pre tt{margin:0;padding:0;background-color:transparent;border:0}</style>
<div class="rendered-markdown"><!-- ### What is this?
This `README.md` file is auto-created for all new projects.

### Why am I here?
This file opens automatically when you open a project. 

If you do not create Guides, this `README.md` will be what automatically opens for students. You can edit this file by clicking on the pencil icon in the upper right corner.

### How do I get started with Codio?
Use this [Onboarding Guide](https://codio.com/home/starter-packs/2ae8501b-e5f7-4b07-8e9f-adb155fc6d10) for an interactive tutorial through the main features of Codio. Click on the link, click **Use Pack** and then click **Create** to add it to your projects.

### How do I close this file?
At the top of your workspace you will see tabs for each open file. Click the x on the right hand side of the tab that says **README.md**.
![readMeTab](https://global.codio.com/platform/readme.resources/readMeTab.png)

### I expected to see or edit learning materials.
Select **Tools->Guide->Play** to view the Guide for this project.
![playGuide](https://global.codio.com/platform/readme.resources/playGuide.png)

Click on the **Open Guides Editor** icon to edit the Guide.
![guideEdit](https://global.codio.com/platform/readme.resources/guideEdit.png)

### How do I delete this file?
To delete this `README.md` file, right-click (ctrl-click on a Mac) on the file name in the file list.
![fileTree](https://global.codio.com/platform/readme.resources/fileTree.png) -->
<p>Introduction:
<br  />The Flask application provides an interactive interface for users to view and analyse data from the World Bank- United States dataset. The application allows us to select and visualize various indicators and time periods using charts(pie, line) and graphs.
<br  />Development:
<br  />Started by Meticulously planning the design stages. Creating of the Git Repository and storing the data, Finding the correct database, using pares_csv.py importing the database, utilizing the Flask framework, utilizing the appropriate templates, testing the data, handling the errors, and finally publishing the complete developed application using render.
<br  />The modular approach is used to develop the application, with separate files for each components such as, Data access, Data processing, and interface.
<br  />Implementation:
<br  />The required dependencies was installed using pip before deploying the application into the cloud-based server.
<br  />For the World Bank-US, I have created a database-driven Flask application with 2 linked tables for this task. The following steps defines the step by step procedure,
<br  />Creating wireless frameworks, and implementing all the logics into the application development. Two csv files holding data of US world bank data. The data is parsed before being inserted into the SQLite database(datausa.db). Importing all the required libraries into the application and using them conveniently where ever required.
<br  />Designed separate HTML files for the searches and index, and also css files for implementing the styles to the HTML format to make it appear good. Created a python program to call the data. And routed the URL’s according to the requirements and later downloading the CSV file and importing the data and passing the two tables and fetching the required data.
<br  />Usage:
<br  />For using the application,</p>
<ol>
<li><p>navigate to the home page using the link https://data.worldbank.org/</p>
</li>
<li><p>Click on the search input field, enter the country name to search- United States.</p>
</li>
<li><p>The page will be redirected to the next page https://data.worldbank.org/country/united-states</p>
</li>
<li><p>In this page we can see all the graphs, charts, data about the country, and also files to be used for download CSV, XML, Excel.</p>
</li>
<li><p>Download the CSV file and unzip the zipped folder and fetch the data from the excel sheet.</p>
</li>
<li><p>Fetch the data from the required Excel which are present in the rows.</p>
</li>
<li><p>Unzip the csv file and import the csv data to the datasets folder.</p>
</li>
<li><p>Create the parse_csv.py file and assign the data.</p>
</li>
<li><p>Run the parse_csv.py to create the db.</p>
</li>
<li><p>Once db is created call the db into the py application and fetch the tables accordingly.</p>
</li>
<li><p>Click on the project->Box Info-> and copy the link and paste the same link into the other tab to see the tables created. If we make any changes in the program then we need to click on refresh so that the data gets populated or use app.run(host='0.0.0.0', debug=True)  to refresh the page automatically.
<br  />Git Repository address:
<br  />HTTPS connection link:
<br  />https://github.com/praneethkotte/Programming-assessment.git
<br  />SSH connection Link:
<br  />git@github.com:praneethkotte/Programming-assessment.git
<br  />Conclusion:
<br  />Flask application provides a simple and intuitive interface for users to access and analyze data from the World Bank- United States dataset. The Use of External libraries and Modular design makes the application easy to maintain and extend.</p>
</li>
</ol>
</div>